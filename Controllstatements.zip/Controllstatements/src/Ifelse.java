public class Ifelse {  
public static void main(String[] args)
{   
    int number=12;   
    if(number%2==0)
    {  
        System.out.println("even number");  
    }
    else
    {  
        System.out.println("odd number");  
    }  
}  
}  