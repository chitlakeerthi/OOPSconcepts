public class Ifstatement {  
public static void main(String[] args) 
{    
    int age=22;    
    if(age>20)
    {  
        System.out.print("Age is greater than 20");  
    }  
}  
}  
