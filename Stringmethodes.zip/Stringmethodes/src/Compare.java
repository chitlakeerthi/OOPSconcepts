public class Compare{  
public static void main(String args[]){  
String s1="hello";  
String s2="hello";  
String s3="hi";  
String s4="hcl";  
String s5="flag";  
System.out.println(s1.compareTo(s2));
System.out.println(s1.compareTo(s3));  
System.out.println(s1.compareTo(s4));
System.out.println(s1.compareTo(s5));  
}}  

