public class Equals{  
public static void main(String args[]){  
String s1="hi";  
String s2="hi";  
String s3="hello";  
String s4="HI";  
System.out.println(s1.equals(s2));
System.out.println(s1.equals(s3));  
System.out.println(s1.equals(s4));  
}}  
