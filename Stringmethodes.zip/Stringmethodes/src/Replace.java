public class Replace{  
public static void main(String args[]){  
String s1="Replace strings";  
String replaceString=s1.replace('s','a');
System.out.println(replaceString);  
}}  
