public class Substring{  
public static void main(String args[]){  
String s1="Welcome";  
System.out.println(s1.substring(2,4)); 
System.out.println(s1.substring(2)); 
}}  
